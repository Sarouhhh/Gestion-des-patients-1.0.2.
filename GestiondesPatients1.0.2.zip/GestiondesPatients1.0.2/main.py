from flask import Flask, render_template, request,jsonify
import requests
import json
import datetime

app = Flask(__name__)

# Page d'accueil
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/listpatients')
def getPatients():
    url = 'https://hapi.fhir.org/baseDstu3/Patient?_sort%3Adesc=_lastUpdated'
    response = requests.get(url).json()
    print(response)
    responsecont= response["entry"]
    contentJson =  responsecont
    return render_template("listePatients.html", patients=responsecont )



# Ajouter un patient
@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        # Récupérer les données saisies par l'utilisateur
        patient_id = request.form['patient_id']
        first_name = request.form['patient_prenom']
        last_name = request.form['patient_nom']
        birth_date = request.form['patient_date_naissance']
        gender = request.form['patient_genre']

        # Construire l'objet patient à partir des données saisies
        patient = {
            'resourceType': 'Patient',
            'id': patient_id,
            'name': [{
                'family': last_name,
                'given': [first_name]

            }],
            'gender': gender,
            'birthDate': birth_date
        }

        # Envoyer la requête POST pour ajouter le patient
        headers = {'Content-Type': 'application/json'}
        url = 'https://hapi.fhir.org/baseDstu3/Patient' # Modifier le endpoint pour FHIR R4
        patientJson = json.dumps(patient)
        response = requests.post(url, headers=headers, json=patient)
        print(response.status_code)

        if response.status_code == 201:
            # Récupérer le patient ajouté
            url = 'https://hapi.fhir.org/baseDstu3/Patient/' + patient_id # Modifier le endpoint pour FHIR R4
            response = requests.get(url)
            added_patient = response.json()

            # Afficher le patient ajouté
            return render_template('new.html')
        # else:
        #     error_message = 'Une erreur est survenue lors de l\'ajout du patient'
        #     return render_template('error.html', message=error_message)

    return render_template('add.html')


# Supprimer un patient
@app.route('/delete', methods=['GET', 'POST'])
def delete():
    if request.method == 'POST':
        patient_id = request.form['patient_id']

        # Supprimer le patient de FHIR
        url = f'https://hapi.fhir.org/baseDstu3/Patient/{patient_id}'
        response = requests.delete(url)

        # Afficher un message de confirmation ou d'erreur
        if response.status_code == 204:
            message = f'Le patient avec l\'ID {patient_id} a été supprimé avec succès.'
            return render_template('deleteOK.html')
     #   else:
     #       error = f'Erreur lors de la suppression du patient avec l\'ID {patient_id}.'
     #       return render_template('delete.html', error=error)

    return render_template('delete.html')
# Rechercher un patient
@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        patient_id = request.form['id']

        # Rechercher le patient dans FHIR
        url = f'https://hapi.fhir.org/baseDstu3/Patient/{patient_id}' # Modifier le endpoint pour FHIR R4
        response = requests.get(url)
        # Afficher les données du patient ou un message d'erreur
        if response.status_code == 200:
            patient_data = response.json()

            # patient_data= patient_data['entry']
            return render_template('search.html', patient=patient_data)


    return render_template('search.html')
 #       else:
 #           error = f'Aucun patient trouvé avec l\'ID {patient_id}.'
 #       return render_template('search.html')
if __name__ == "__main__":    app.run(debug=True)


